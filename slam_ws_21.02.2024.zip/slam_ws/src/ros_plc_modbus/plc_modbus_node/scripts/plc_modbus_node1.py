#!/usr/bin/env python
import rospy
from std_msgs.msg import UInt16MultiArray, ByteMultiArray
import modbus_tk.modbus_tcp as modbus

class PLCModbusManager:
    def __init__(self):
        rospy.init_node('ros_plc_modbus')
        
        self.regs_read = rospy.Publisher('modbus/regs_read', UInt16MultiArray, queue_size=100)
        self.regs_write = rospy.Subscriber('modbus/regs_write', UInt16MultiArray, self.regs_callback)
        self.coils_read = rospy.Publisher('modbus/coils_read', ByteMultiArray, queue_size=100)
        self.coils_write = rospy.Subscriber('modbus/coils_write', ByteMultiArray, self.coils_callback)

        self.regs_addr = rospy.get_param('~regs_addr', [])
        self.coils_addr = rospy.get_param('~coils_addr', [])

        self.regs_val = UInt16MultiArray()
        self.coils_val = ByteMultiArray()

        self.ip_address = rospy.get_param('~ip', '192.168.1.5')
        self.port = rospy.get_param('~port', 502)
        self.spin_rate = rospy.get_param('~spin_rate', 30)

        self.plc = modbus.TcpMaster(self.ip_address, self.port)
        try:
            self.plc.open()
            rospy.loginfo('Connection to modbus device established')
        except modbus.ModbusError as e:
            rospy.logfatal('Failed to connect to modbus device!!!\n%s', str(e))
            rospy.signal_shutdown('Unable to connect to modbus device')

        rate = rospy.Rate(self.spin_rate)
        while not rospy.is_shutdown():
            self.regs_val.data = []
            self.coils_val.data = []

            for addr in self.regs_addr:
                try:
                    temp = self.plc.execute(1, modbus.READ_HOLDING_REGISTERS, addr, 1)
                    self.regs_val.data.append(temp[0])
                except modbus.ModbusError as e:
                    rospy.logerr('Unable to read reg addr:%d\n%s', addr, str(e))

            if self.regs_val.data:
                self.regs_read.publish(self.regs_val)

            for addr in self.coils_addr:
                try:
                    temp = self.plc.execute(1, modbus.READ_COILS, addr, 1)
                    self.coils_val.data.append(temp[0])
                except modbus.ModbusError as e:
                    rospy.logerr('Unable to read coil addr:%d\n%s', addr, str(e))

            if self.coils_val.data:
                self.coils_read.publish(self.coils_val)

            rate.sleep()

        self.plc.close()
        rospy.loginfo('Connection to modbus device closed')

    def regs_callback(self, regs_data):
        if len(regs_data.data) != len(self.regs_addr):
            rospy.logerr('%d registers to write but only %d given!', len(self.regs_addr), len(regs_data.data))
            return

        for i, value in enumerate(regs_data.data):
            try:
                self.plc.execute(1, modbus.WRITE_MULTIPLE_REGISTERS, self.regs_addr[i], output_value=(value,))
                rospy.loginfo('Modbus register write at addr:%d with value:%u', self.regs_addr[i], value)
            except modbus.ModbusError as e:
                rospy.logerr('Modbus reg write failed at addr:%d with value:%u\n%s', self.regs_addr[i], value, str(e))

    def coils_callback(self, coils_data):
        if len(coils_data.data) != len(self.coils_addr):
            rospy.logerr('%d coils to write but %d given!', len(self.coils_addr), len(coils_data.data))
            return

        for i, value in enumerate(coils_data.data):
            try:
                self.plc.execute(1, modbus.WRITE_SINGLE_COIL, self.coils_addr[i], output_value=(value,))
                rospy.loginfo('Modbus coil write at addr:%d with value:%u', self.coils_addr[i], value)
            except modbus.ModbusError as e:
                rospy.logerr('Modbus coil write failed at addr:%d with value:%u\n%s', self.coils_addr[i], value, str(e))

if __name__ == '__main__':
    try:
        PLCModbusManager()
    except rospy.ROSInterruptException:
        pass

