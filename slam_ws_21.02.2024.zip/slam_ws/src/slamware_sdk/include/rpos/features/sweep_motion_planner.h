/**
* sweep_motion_planner.h
* Sweep Motion Planner Feature
*
* Created By Tony Huang at 2015-4-3
* Copyright 2015 (c) Shanghai Slamtec Co., Ltd.
*/

#pragma once

#include "sweep_motion_planner/feature.h"
#include "sweep_motion_planner/sweep_move_action.h"
