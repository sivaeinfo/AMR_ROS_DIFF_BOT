#pragma once

#define RPOS_VERSION_MAJOR    4
#define RPOS_VERSION_MINOR    5
#define RPOS_VERSION_REVISION    5
#define RPOS_VERSION_SUFFIX    "dev"
#define RPOS_VERSION_SHORT    "4.5"
#define RPOS_VERSION_LONG    "4.5.0"
#define RPOS_VERSION_FULL    "4.5.0_dev"

